//
//  MyFirstTableViewController.h
//  EmptyApplication
//
//  Created by Yiheng Ding on 7/3/15.
//  Copyright (c) 2015 StudentName. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyFirstTableViewController : UITableViewController<UITableViewDelegate, UITableViewDataSource>


@end
